export interface Trustee{
    id:string,
    name:string,
    gender:string,
    country:string,
    passport:string,
    date:Date,
    dependent:number
  
  }