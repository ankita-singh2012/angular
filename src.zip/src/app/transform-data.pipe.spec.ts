import { TransformDataPipe } from './transform-data.pipe';

describe('TransformDataPipe', () => {
  it('create an instance', () => {
    const pipe = new TransformDataPipe();
    expect(pipe).toBeTruthy();
  });
});
