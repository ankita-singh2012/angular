import { Component } from '@angular/core';

@Component({
  selector: 'app-appabout',
  templateUrl: './appabout.component.html',
  styleUrls: ['./appabout.component.css']
})
export class AppaboutComponent {

}
