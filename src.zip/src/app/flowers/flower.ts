export interface IFlower{
    id:string,
    name:string,
    place:string,
    price:number,
    image:string,
    Quantity: number
}