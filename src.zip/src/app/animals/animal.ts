export interface Animal{
    id: string,
    name: string;
    description: string;
    age: number;
    imageUrl: string;
}